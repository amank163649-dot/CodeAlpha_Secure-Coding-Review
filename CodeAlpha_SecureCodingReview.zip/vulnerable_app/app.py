"""
CodeAlpha Secure Coding Review - Sample Application (VULNERABLE VERSION)
--------------------------------------------------------------------------
A small Flask "user portal" that intentionally reproduces common, realistic
vulnerability patterns so they can be reviewed and remediated. Do NOT deploy
this file as-is. See analysis/findings.md and fixed_app/ for the corrected
version.
"""

import os
import sqlite3
import hashlib
import pickle
import subprocess

from flask import Flask, request, render_template_string, redirect, make_response

app = Flask(__name__)

# ---------------------------------------------------------------------------
# FINDING 1 (CWE-798): Hardcoded secret key committed to source control.
app.secret_key = "s3cr3t_dev_key_123"

DB_PATH = os.path.join(os.path.dirname(__file__), "users.db")


def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.execute(
        "CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY, "
        "username TEXT, password TEXT, is_admin INTEGER DEFAULT 0)"
    )
    return conn


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form["username"]
        password = request.form["password"]

        # FINDING 2 (CWE-89): SQL Injection via string concatenation.
        conn = get_db()
        query = "SELECT * FROM users WHERE username = '%s' AND password = '%s'" % (
            username,
            hashlib.md5(password.encode()).hexdigest(),  # FINDING 3 (CWE-327): MD5 for password hashing
        )
        cursor = conn.execute(query)
        user = cursor.fetchone()

        if user:
            resp = make_response(redirect("/dashboard"))
            # FINDING 4 (CWE-614 / CWE-1004): Session cookie missing Secure,
            # HttpOnly and SameSite attributes.
            resp.set_cookie("session_user", username)
            return resp
        return "Invalid credentials", 401

    return """
        <form method="post">
            Username: <input name="username"><br>
            Password: <input name="password" type="password"><br>
            <input type="submit">
        </form>
    """


@app.route("/dashboard")
def dashboard():
    username = request.cookies.get("session_user", "")
    # FINDING 5 (CWE-79): Reflected/stored XSS via render_template_string
    # with unsanitized, attacker-controlled input rendered as a template.
    template = "<h1>Welcome back, " + username + "!</h1>"
    return render_template_string(template)


@app.route("/profile/<username>")
def profile(username):
    conn = get_db()
    # FINDING 2b (CWE-89): Same SQL injection pattern reused here.
    cursor = conn.execute("SELECT * FROM users WHERE username = '" + username + "'")
    user = cursor.fetchone()
    return str(user)


@app.route("/ping")
def ping():
    host = request.args.get("host", "127.0.0.1")
    # FINDING 6 (CWE-78): OS command injection - user input passed to shell.
    result = subprocess.check_output("ping -c 1 " + host, shell=True)
    return result


@app.route("/download")
def download():
    filename = request.args.get("file", "readme.txt")
    # FINDING 7 (CWE-22): Path traversal - no sanitization of filename,
    # allows ../../etc/passwd style access.
    path = os.path.join(os.path.dirname(__file__), "files", filename)
    with open(path, "rb") as f:
        return f.read()


@app.route("/load_prefs", methods=["POST"])
def load_prefs():
    # FINDING 8 (CWE-502): Insecure deserialization - unpickling
    # attacker-supplied bytes can lead to remote code execution.
    data = request.get_data()
    prefs = pickle.loads(data)
    return str(prefs)


@app.route("/admin")
def admin():
    username = request.cookies.get("session_user", "")
    # FINDING 9 (CWE-284/CWE-862): Broken access control - "admin" status
    # is inferred from a client-supplied cookie value rather than a
    # verified server-side session/role check.
    if username == "admin":
        return "Welcome, administrator. All user records: " + str(get_db().execute("SELECT * FROM users").fetchall())
    return "Forbidden", 403


if __name__ == "__main__":
    # FINDING 10 (CWE-489): Debug mode enabled - exposes the Werkzeug
    # interactive debugger/RCE console and stack traces in production.
    app.run(host="0.0.0.0", debug=True)
