"""
CodeAlpha Secure Coding Review - Sample Application (FIXED VERSION)
--------------------------------------------------------------------------
Remediated version of vulnerable_app/app.py. Every FINDING comment from the
original file is resolved here using the corresponding secure pattern.
Passwords use Werkzeug's PBKDF2/bcrypt-backed hashing, all queries are
parameterized, secrets come from the environment, and so on.

This is a teaching example (still uses SQLite/no ORM for simplicity) -
production systems should also add rate limiting, CSRF protection (e.g.
Flask-WTF), structured logging, and a real session framework.
"""

import os
import sqlite3
import subprocess
import ipaddress
import json

from markupsafe import escape
from werkzeug.security import generate_password_hash, check_password_hash
from flask import Flask, request, redirect, make_response, session, abort

app = Flask(__name__)

# FIX 1: Secret key loaded from environment, never hardcoded/committed.
# Fails fast if not set, instead of silently using a weak default.
app.secret_key = os.environ.get("FLASK_SECRET_KEY")
if not app.secret_key:
    raise RuntimeError("FLASK_SECRET_KEY environment variable must be set")

app.config.update(
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SECURE=True,      # requires HTTPS in production
    SESSION_COOKIE_SAMESITE="Lax",
)

DB_PATH = os.path.join(os.path.dirname(__file__), "users.db")
FILES_DIR = os.path.join(os.path.dirname(__file__), "files")


def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.execute(
        "CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY, "
        "username TEXT UNIQUE, password_hash TEXT, is_admin INTEGER DEFAULT 0)"
    )
    return conn


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form["username"]
        password = request.form["password"]

        # FIX 2: Parameterized query - no string concatenation/formatting.
        conn = get_db()
        cursor = conn.execute(
            "SELECT id, username, password_hash, is_admin FROM users WHERE username = ?",
            (username,),
        )
        user = cursor.fetchone()

        # FIX 3: Salted, adaptive hash (PBKDF2-SHA256 via Werkzeug) instead
        # of unsalted MD5. Comparison happens against the stored hash.
        if user and check_password_hash(user[2], password):
            # FIX 9: Real server-side session instead of a trust-me cookie.
            session.clear()
            session["user_id"] = user[0]
            session["is_admin"] = bool(user[3])
            resp = make_response(redirect("/dashboard"))
            return resp
        return "Invalid credentials", 401

    return """
        <form method="post">
            Username: <input name="username"><br>
            Password: <input name="password" type="password"><br>
            <input type="submit">
        </form>
    """


@app.route("/dashboard")
def dashboard():
    if "user_id" not in session:
        return redirect("/login")
    conn = get_db()
    user = conn.execute(
        "SELECT username FROM users WHERE id = ?", (session["user_id"],)
    ).fetchone()
    # FIX 5: No template injection - plain string formatting with
    # Jinja's autoescaping (escape()) applied to any user-controlled value.
    return f"<h1>Welcome back, {escape(user[0])}!</h1>"


@app.route("/profile/<username>")
def profile(username):
    conn = get_db()
    # FIX 2b: Parameterized query.
    user = conn.execute(
        "SELECT id, username FROM users WHERE username = ?", (username,)
    ).fetchone()
    if not user:
        abort(404)
    return {"id": user[0], "username": escape(user[1])}


ALLOWED_PING_TARGETS = {"127.0.0.1", "localhost"}


@app.route("/ping")
def ping():
    host = request.args.get("host", "127.0.0.1")
    # FIX 6: Strict allow-list + validation instead of shell interpolation.
    # No shell=True; arguments passed as a list so there is no shell to
    # inject into.
    try:
        ipaddress.ip_address(host)
    except ValueError:
        if host not in ALLOWED_PING_TARGETS:
            abort(400, "Invalid host")
    result = subprocess.check_output(["ping", "-c", "1", host], shell=False)
    return result


@app.route("/download")
def download():
    filename = request.args.get("file", "readme.txt")
    # FIX 7: Resolve the path and verify it is still inside FILES_DIR,
    # rejecting any ../ traversal attempts, and reject path separators
    # outright as a first line of defense.
    if os.path.sep in filename or (os.path.altsep and os.path.altsep in filename):
        abort(400, "Invalid filename")
    safe_path = os.path.realpath(os.path.join(FILES_DIR, filename))
    if not safe_path.startswith(os.path.realpath(FILES_DIR) + os.sep):
        abort(400, "Invalid filename")
    with open(safe_path, "rb") as f:
        return f.read()


@app.route("/load_prefs", methods=["POST"])
def load_prefs():
    # FIX 8: JSON instead of pickle - no arbitrary object deserialization,
    # so there is no code-execution gadget chain to exploit.
    try:
        prefs = json.loads(request.get_data())
    except json.JSONDecodeError:
        abort(400, "Invalid preferences payload")
    return prefs


@app.route("/admin")
def admin():
    # FIX 9b: Authorization decision comes from the signed server-side
    # session, not a client-suppliable cookie value.
    if "user_id" not in session:
        return redirect("/login")
    if not session.get("is_admin"):
        abort(403)
    conn = get_db()
    rows = conn.execute("SELECT id, username, is_admin FROM users").fetchall()
    return {"users": rows}


if __name__ == "__main__":
    # FIX 10: Debug mode off; host binding should be scoped by the
    # deployment environment (reverse proxy / container network), and a
    # production WSGI server (gunicorn/uwsgi) should run this app, not
    # Flask's built-in dev server.
    app.run(host="127.0.0.1", debug=False)
