# CodeAlpha_SecureCodingReview

**CodeAlpha Cyber Security Internship — Task 3: Secure Coding Review**

## What this repo contains

| Folder / File | Purpose |
|---|---|
| `vulnerable_app/app.py` | Sample Flask app containing 10 intentionally realistic vulnerabilities, used as the review target |
| `fixed_app/app.py` | Fully remediated version — every finding resolved |
| `analysis/bandit_report.txt` | Raw Bandit static-analysis output **before** remediation |
| `analysis/bandit_report_fixed.txt` | Raw Bandit static-analysis output **after** remediation (0 High/Medium issues) |
| `Secure_Coding_Review_Report.docx` | Full write-up: methodology, findings table, per-finding detail (impact, evidence, fix), and recommendations |

## Methodology

1. Picked a small Python/Flask application as the audit target.
2. Ran **Bandit** (SAST tool) for automated detection.
3. Performed a manual line-by-line review against the OWASP Top 10 / CWE Top 25.
4. Documented each finding with severity, CWE ID, evidence, impact, and remediation.
5. Rewrote the application fixing every issue, then re-ran Bandit to confirm the fixes (0 High, 0 Medium remaining).

## Findings at a glance

| ID | Finding | Severity |
|---|---|---|
| 1 | Hardcoded secret key | Low |
| 2 | SQL Injection (2 locations) | Medium |
| 3 | Weak password hashing (MD5) | High |
| 4 | Insecure session cookie attributes | Medium |
| 5 | XSS via template injection | High |
| 6 | OS command injection | High |
| 7 | Path traversal | High |
| 8 | Insecure deserialization (pickle) | High |
| 9 | Broken access control | High |
| 10 | Debug mode enabled | Medium |

See `Secure_Coding_Review_Report.docx` for full details.

## How to reproduce the scan

```bash
pip install bandit flask werkzeug markupsafe
bandit -r vulnerable_app/app.py -f txt      # before
bandit -r fixed_app/app.py -f txt           # after
```

## Internship submission checklist
- [x] Uploaded source code to GitHub as `CodeAlpha_SecureCodingReview`
- [ ] Post a LinkedIn video walkthrough tagging **@CodeAlpha**, linking this repo
- [ ] Submit via the official Submission Form shared in the WhatsApp group
